CREATE TABLE [dbo].[Dim_TypePret] (

	[loan_intent] varchar(8000) NULL, 
	[Type_France] varchar(12) NULL
);