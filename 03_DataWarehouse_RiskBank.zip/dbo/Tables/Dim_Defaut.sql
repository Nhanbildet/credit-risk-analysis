CREATE TABLE [dbo].[Dim_Defaut] (

	[DefautID] decimal(38,6) NULL, 
	[Défaut.Status] varchar(11) NOT NULL
);