CREATE TABLE [dbo].[Dim_TypePret_Gold1] (

	[Type Pret] varchar(8000) NULL, 
	[Type_France] varchar(8000) NULL, 
	[PretID] varchar(8000) NULL, 
	[Type Francaise] varchar(8000) NULL
);