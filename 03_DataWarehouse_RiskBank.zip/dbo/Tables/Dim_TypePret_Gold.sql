CREATE TABLE [dbo].[Dim_TypePret_Gold] (

	[Type Pret] varchar(8000) NULL, 
	[PretID] varchar(8000) NULL
);