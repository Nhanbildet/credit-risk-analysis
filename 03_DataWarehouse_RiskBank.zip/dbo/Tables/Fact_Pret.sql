CREATE TABLE [dbo].[Fact_Pret] (

	[ClientID] varchar(8000) NULL, 
	[LocationID] varchar(8000) NOT NULL, 
	[Taux] varchar(8000) NULL, 
	[Classe_de_crédit] varchar(8000) NULL, 
	[Type_de_prêt] varchar(8000) NULL, 
	[loan_amnt] int NULL, 
	[Part_du_revenu] decimal(7,2) NULL, 
	[Défaut] decimal(3,1) NULL, 
	[Durée_du_prêt] int NULL, 
	[Ratio_prêt_revenu] decimal(7,2) NULL, 
	[Ancienneté_crédit_ans] int NULL, 
	[Antécédent_défaut] int NULL, 
	[Ratio_dette_revenu] decimal(8,2) NULL, 
	[nb_compt] int NULL, 
	[Utilisation_crédit] decimal(8,1) NULL, 
	[Retards_paiement] int NULL, 
	[Autres_dettes] decimal(20,2) NULL, 
	[rank_pret_revenue] int NULL
);