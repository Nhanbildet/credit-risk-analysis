CREATE TABLE [dbo].[Fact_Pret_Gold] (

	[ClientID] varchar(8000) NULL, 
	[LocationID] varchar(8000) NULL, 
	[Taux] float NULL, 
	[Classe_de_crédit] varchar(8000) NULL, 
	[loan_amnt] int NULL, 
	[Part_du_revenu] decimal(38,6) NULL, 
	[Défaut] decimal(38,6) NULL, 
	[Durée_du_prêt] int NULL, 
	[Ratio_prêt_revenu] decimal(38,6) NULL, 
	[Ancienneté_crédit_ans] int NULL, 
	[Antécédent_défaut] int NULL, 
	[Ratio_dette_revenu] decimal(38,6) NULL, 
	[nb_compt] int NULL, 
	[Utilisation_crédit] decimal(38,6) NULL, 
	[Retards_paiement] int NULL, 
	[Autres_dettes] decimal(38,6) NULL, 
	[PretID] varchar(8000) NULL
);