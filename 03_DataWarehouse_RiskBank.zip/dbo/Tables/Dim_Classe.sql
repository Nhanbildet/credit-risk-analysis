CREATE TABLE [dbo].[Dim_Classe] (

	[loan_grade] varchar(8000) NULL
);