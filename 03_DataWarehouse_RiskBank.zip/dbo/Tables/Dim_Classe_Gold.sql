CREATE TABLE [dbo].[Dim_Classe_Gold] (

	[Classe_de_crédit] varchar(8000) NULL
);