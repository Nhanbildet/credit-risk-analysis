CREATE TABLE [dbo].[Dim_Clients] (

	[ClientID] varchar(8000) NULL, 
	[LocationID] varchar(8000) NOT NULL, 
	[Type_de_prêt] varchar(8000) NULL, 
	[Classe_de_crédit] varchar(8000) NULL, 
	[Âge] int NULL, 
	[Genre] varchar(8000) NULL, 
	[Statut_marital] varchar(8000) NULL, 
	[Statut_logement] varchar(8000) NULL, 
	[Education] varchar(8000) NULL, 
	[Revenue_manuel] int NULL, 
	[Ancienneté] int NULL, 
	[Type_employ] varchar(8000) NULL
);