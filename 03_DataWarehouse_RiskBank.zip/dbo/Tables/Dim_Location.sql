CREATE TABLE [dbo].[Dim_Location] (

	[LocationID] varchar(8000) NOT NULL, 
	[Pays] varchar(8000) NULL, 
	[Region] varchar(8000) NULL, 
	[ville] varchar(8000) NULL, 
	[Latitude] varchar(8000) NULL, 
	[longitude] varchar(8000) NULL
);