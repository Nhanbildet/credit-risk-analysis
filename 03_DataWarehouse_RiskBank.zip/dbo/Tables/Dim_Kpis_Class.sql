CREATE TABLE [dbo].[Dim_Kpis_Class] (

	[Classe_de_crédit] varchar(8000) NULL, 
	[nb_loans] int NULL, 
	[total_loan_amount] int NULL, 
	[avg_Part_revenu] decimal(20,2) NULL, 
	[avg_Ratio_dette_revenue] decimal(20,2) NULL, 
	[avg_nv_compt] int NULL, 
	[avg_retard_payment] decimal(38,6) NULL, 
	[AVG_defaut] decimal(10,2) NULL, 
	[Total_autre_dette] decimal(38,2) NULL, 
	[Antécédent_défaut_ratio] decimal(4,2) NULL, 
	[avg_credit_ans] decimal(38,6) NULL
);