-- Auto Generated (Do not modify) 5184013442B055DC1278F6464B30627CC71DC851793AA7ECAEC506FE1952C645
CREATE   VIEW View_pret AS
SELECT DISTINCT
loan_intent,
CASE 
    WHEN loan_intent = 'EDUCATION' THEN 'Éducation'
    WHEN loan_intent = 'MEDICAL' THEN 'Médical'
    WHEN loan_intent = 'PERSONAL' THEN 'Personnel'
    WHEN loan_intent = 'HOMEIMPROVEMENT' THEN 'Habitat'
    WHEN loan_intent = 'DEBTCONSOLIDATION' THEN 'Conso dettes'
    WHEN loan_intent = 'VENTURE' THEN 'Projet'
    ELSE NULL
 END AS Type_France
FROM Credit_Silverlayer