-- Auto Generated (Do not modify) AFBE80B684FE11FD2DFB2DCE4FB6168B40DFBC1D2093693865133B9F84D5206C
CREATE   VIEW View_KPI_Prete AS
SELECT
    Type_de_prêt,
    COUNT(*) AS nb_loans,
    SUM(loan_amnt) AS total_loan_amount,
    CAST(AVG(Part_du_revenu) as DECIMAL(20,2)) AS avg_Part_revenu,
    CAST(AVG(Ratio_dette_revenu) as DECIMAL(20,2)) as avg_Ratio_dette_revenue,
    AVG(nb_compt) as avg_nv_compt,
    AVG(CAST(Retards_paiement AS DECIMAL(20,2))) as avg_retard_payment,
    CAST(SUM(Défaut)*100/ COUNT(*) AS DECimal(10,2)) AS AVG_defaut,
    SUM(Autres_dettes) as Total_autre_dette,
    CAST(SUM(Antécédent_défaut)*100/ COUNT(*) AS DECimal(4,2)) AS Antécédent_défaut_ratio,
    AVG(CAST(Ancienneté_crédit_ans as DECIMAL(4,2))) As avg_credit_ans

FROM Fact_Pret
GROUP BY Type_de_prêt;