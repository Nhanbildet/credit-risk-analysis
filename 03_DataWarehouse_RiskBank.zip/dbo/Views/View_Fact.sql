-- Auto Generated (Do not modify) B9C6A4C9FFE514CEAD252C52DAED0F4CE01ADE081FB9AC1DB741C964EBD26F7F
CREATE   VIEW View_Fact AS
SELECT 
 client_ID as ClientID,
 LocationID,
loan_int_rate AS Taux,
 loan_grade AS Classe_de_crédit,
 loan_intent AS Type_de_prêt,
 loan_amnt,
 CAST(REPLACE(loan_percent_income, ',', '.')  as DECIMAL(3,2)) * 100 AS Part_du_revenu,
 CAST(loan_status AS DECIMAL(3,1)) AS Défaut,
 loan_term_months AS Durée_du_prêt,
 CAST(REPLACE(loan_to_income_ratio,',','.') AS DECimal(3,2)) * 100 AS Ratio_prêt_revenu,
 cb_person_cred_hist_length AS Ancienneté_crédit_ans,
 CASE 
    WHEN cb_person_default_on_file = 'Y' THEN 1
    WHEN cb_person_default_on_file = 'N' THEN 0
    ELSE NULL
 END AS Antécédent_défaut,
 CAST(REPLACE(debt_to_income_ratio,',','.') AS DECIMAL(4,2)) *100  AS Ratio_dette_revenu,
 open_accounts AS nb_compt,
 CAST(REPLACE( credit_utilization_ratio,',','.') AS DECIMAL(4,1)) *100 AS Utilisation_crédit,
 past_delinquencies AS Retards_paiement,
 CAST(REPLACE(other_debt ,',','.') AS DECIMAL(20,2)) AS Autres_dettes,
 CAST(
   FLOOR(
      CAST(REPLACE(loan_to_income_ratio, ',', '.') AS DECIMAL(5,2))* 10)
   AS INT) AS rank_pret_revenue
 
FROM Credit_Silverlayer