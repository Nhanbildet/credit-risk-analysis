-- Auto Generated (Do not modify) 465A38CE4D418FA2C4A37D77B0936EDDC639DCF39ECAC578CBDB3269B9C61400
CREATE   VIEW View_location AS
SELECT  
LocationID, 
country AS Pays,
state AS Region,
city AS ville,
city_latitude AS Latitude,
city_longitude AS longitude
FROM Credit_Silverlayer;