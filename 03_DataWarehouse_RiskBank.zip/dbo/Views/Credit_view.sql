-- Auto Generated (Do not modify) D6E1BBA94531D6BC435E791F362CA71A2CD9AF2E5D265BD27961FFFDDAE88587
CREATE   VIEW Credit_view AS
    SELECT
    *,
    CONCAT(city_latitude,city_longitude) as LocationID
     

    FROM RiskBank.dbo.credit_risk_dataset;